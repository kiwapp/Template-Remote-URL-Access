(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
require('../helpers/helpers');

angular.module('kiwappSetup', ['ngAnimate', 'ngTouch', 'ngSanitize', 'ngBabelfish', 'ui.router', 'kiwapp.api', 'helpers'])
    .controller('MainCtrl', require('./controllers/MainCtrl'))
    .factory('AppInstanceFactory', require('./factory/appInstanceFactory'))
    .config(["$stateProvider", "$urlRouterProvider", "babelfishProvider", function ($stateProvider, $urlRouterProvider, babelfishProvider) {
        'use strict';

        $stateProvider
            .state('home', {
                url: '/',
                templateUrl: 'core/partials/main.html',
                controller: 'MainCtrl',
                resolve: {
                    AppInstanceData: ["AppInstanceFactory", function (AppInstanceFactory) {
                        console.log("Resolution in progress...");
                        return AppInstanceFactory.load();
                    }]
                }
            });

        $urlRouterProvider.otherwise('/');

        // Init the babelfish module for the translation
        babelfishProvider.init({
            state: "home",
            lang: "fr-FR",
            url: "i18n/languages.json",
            namespace: "i18n",
            lazy: false
        });
    }])
;


},{"../helpers/helpers":4,"./controllers/MainCtrl":2,"./factory/appInstanceFactory":3}],2:[function(require,module,exports){
'use strict';
/*@ngInject*/
module.exports = function ($scope, appInstanceDataApi, browserUtils, babelfish) {

    var keyAppInstanceData = "app-params-remote-url";

    if(browserUtils.getParameterByName('lang')) {
        // Init the languages settings with the value from the lang key in the url
        babelfish.updateLang(browserUtils.getParameterByName('lang'));
        babelfish.load();
    }

    // Use JSON.stringify and parse, this will be prettify the JSON
    var dataAppInstance = appInstanceDataApi.get(keyAppInstanceData);
    if(dataAppInstance !== undefined && appInstanceDataApi.get(keyAppInstanceData).data !== "") {
        $scope.model = JSON.parse(appInstanceDataApi.get(keyAppInstanceData).data);
    } else {
        $scope.model = {
            scroll: true
        };
    }

    /**
     * Save the data
     */
    $scope.save = function() {

        $scope.configForm.subimtted = true;
        $scope.configForm.$setPristine();
        appInstanceDataApi.save(JSON.stringify($scope.model), keyAppInstanceData);
    };
};
module.exports.$inject = ["$scope", "appInstanceDataApi", "browserUtils", "babelfish"];

},{}],3:[function(require,module,exports){
'use strict';
/*@ngInject*/
module.exports = function (appInstanceDataApi) {

    function loadAppInstanceData() {
        console.log("[ENTER] loadAppInstanceData");
        return appInstanceDataApi.load();
    }
    return {
        load : loadAppInstanceData
    };
};
module.exports.$inject = ["appInstanceDataApi"];

},{}],4:[function(require,module,exports){
/**
 * Helpers module
 * Provide some helper to your application
 */
angular.module('helpers', [])
    .service('browserUtils', require('./services/browserUtils'));

},{"./services/browserUtils":5}],5:[function(require,module,exports){
/*@ngInject*/
module.exports = function ($window) {
    'use strict';

    var service = {};

    service.getParameterByName = function getParameterByName(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec($window.location.href);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, " "));
    };

    /**
     * this method will return the browser name
     * @returns string : chrome/safari/firefox/ie
     */
    service.getBrowserName = function getBrowserName() {
        var userAgent = $window.navigator.userAgent;

        var browsers = {chrome: /chrome/i, safari: /safari/i, firefox: /firefox/i, ie: /internet explorer/i};

        for (var key in browsers) {
            if (browsers[key].test(userAgent)) {
                return key;
            }
        }

        return 'unknown';
    };

    /**
     * This method will return true if the input type color is available
     * Liste here : http://caniuse.com/#feat=input-color
     * @returns boolean
     */
    service.inputColorIsAvailable = function inputColorIsAvailable() {

        var browserName = service.getBrowserName();
        if (browserName === "chrome" || browserName === "firefox" || browserName === "opera") {
            return true;
        }
        return false;
    };

    return service;
};
module.exports.$inject = ["$window"];

},{}]},{},[1])


//# sourceMappingURL=app.js.map